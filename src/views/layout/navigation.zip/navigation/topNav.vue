<template>
  <div
    ref="menuContainer"
    class="ape-volo-content h-[calc(100%-4px)] mx-2 flex items-center w-[calc(100vw-600px)] overflow-auto"
  >
    <el-menu
      ref="menuRef"
      :default-active="active"
      mode="horizontal"
      class="border-r-0 w-full flex gap-1 items-center box-border h-[calc(100%-1px)]"
      unique-opened
      :ellipsis="shouldEllipsis"
      @select="selectMenuItem"
    >
      <template v-for="item in menuItems">
        <menu-node
          v-if="!item.hidden"
          :key="item.name"
          :router-info="item"
          mode="horizontal"
        />
      </template>
    </el-menu>
  </div>
</template>

<script setup lang="ts">
  import menuNode from '@/views/layout/navigation/menuNode.vue'
  import { ref, provide, watchEffect, onMounted, nextTick, computed } from 'vue'
  import { useRoute, useRouter } from 'vue-router'
  import { useRouterStore } from '@/pinia/modules/router'
  import type { RouteMenuItem } from '@/pinia/modules/router'
  import { useAppStore } from '@/pinia'
  import { storeToRefs } from 'pinia'
  const appStore = useAppStore()
  const { device } = storeToRefs(appStore)

  defineOptions({
    name: 'HeadMode'
  })
  const route = useRoute()
  const router = useRouter()
  const routerStore = useRouterStore()
  const isCollapse = ref(false)
  const active = ref('')
  const menuRef = ref<any>(null)
  const menuContainer = ref<HTMLDivElement | null>(null)
  const shouldEllipsis = ref(false)

  // 将 asyncRouters 转换为 RouteMenuItem 类型
  const menuItems = computed(() => {
    return (routerStore.asyncRouters[0]?.children || []) as RouteMenuItem[]
  })

  // 计算是否需要启用省略功能
  const calculateEllipsis = async () => {
    await nextTick()
    if (!menuRef.value || !menuContainer.value) return

    const menuElements = menuRef.value.$el.querySelectorAll(
      '.el-menu-item, .el-sub-menu'
    )
    let totalWidth = 0

    menuElements.forEach((item: HTMLElement) => {
      totalWidth += item.offsetWidth
    })

    const containerWidth = menuContainer.value.offsetWidth
    shouldEllipsis.value = totalWidth > containerWidth
  }

  watchEffect(() => {
    active.value = String(route.name || '')
  })

  watchEffect(() => {
    if (device.value === 'mobile') {
      isCollapse.value = true
    } else {
      isCollapse.value = false
    }
    // 设备变化时重新计算
    calculateEllipsis()
  })

  // 当路由变化时重新计算
  watchEffect(() => {
    if (route.name) {
      nextTick(calculateEllipsis)
    }
  })

  provide('isCollapse', isCollapse)

  onMounted(() => {
    calculateEllipsis()
    window.addEventListener('resize', calculateEllipsis)
  })

  const selectMenuItem = (index: string) => {
    if (index === String(route.name || '')) return
    if (index.indexOf('http://') > -1 || index.indexOf('https://') > -1) {
      window.open(index, '_blank')
      return
    } else {
      router.push({ name: index })
    }
  }
</script>
