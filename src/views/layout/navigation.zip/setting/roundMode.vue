<template>
  <div class="p-4 border ape-volo-bg rounded-[var(--ape-volo-radius)] shadow">
    <div class="grid grid-cols-5 gap-4 justify-items-center">
      <button
        v-for="item in roundOptions"
        :key="item.value"
        :class="[
          'flex flex-col items-center w-20 h-10 justify-center rounded-[var(--ape-volo-radius)] select-none cursor-pointer text-lg',
          'ape-volo-bg text-gray-700 dark:text-gray-200 transition-all duration-300',
          'border',
          cornerSizeValue === item.value
            ? '[border-color:var(--el-color-primary)] [box-shadow:0_0_0_1px_var(--el-color-primary)]'
            : 'hover:[border-color:var(--el-color-primary)] hover:[box-shadow:0_0_0_1px_var(--el-color-primary)]'
        ]"
        @click="handleClick(item.value)"
      >
        {{ item.label }}
      </button>
    </div>
  </div>
</template>

<script setup lang="ts">
  import type { PropType } from 'vue'
  import { useAppStore } from '@/pinia'
  import { BorderRadiusType } from '@/enums/BorderRadiusType'

  const appStore = useAppStore()

  const props = defineProps({
    cornerSizeValue: {
      type: Number as PropType<BorderRadiusType>,
      required: true
    }
  })

  const roundOptions = Object.entries(BorderRadiusType)
    .filter(([key]) => isNaN(Number(key)))
    .map(([label, value]) => ({
      label,
      value: value as BorderRadiusType
    }))

  function handleClick(size: BorderRadiusType) {
    if (size !== props.cornerSizeValue) {
      appStore.toggleCornerSize(size)
    }
  }
</script>
