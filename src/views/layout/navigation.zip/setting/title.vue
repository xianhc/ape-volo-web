<template>
  <div class="title relative my-2">
    <div class="flex-shrink-0 text-center text-xl text-gray-600">
      {{ title }}
    </div>
  </div>
</template>

<script setup lang="ts">
  defineOptions({
    name: 'LayoutSettingTitle'
  })

  defineProps({
    title: {
      type: String,
      default: ''
    }
  })
</script>

<style scoped>
  .title {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 4rem;
  }

  .title::before,
  .title::after {
    content: '';
    height: 1px;
    width: 100%;
    background-color: #e3e3e3;
  }
</style>
